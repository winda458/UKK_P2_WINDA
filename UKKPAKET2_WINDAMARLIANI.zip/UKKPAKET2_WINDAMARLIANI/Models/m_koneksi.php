<?php
class m_koneksi {
    private $host = "127.0.0.1",
            $username = "root",
            $pass = "root",
            $db = "UKKPAKET2_WINDAMARLIANI";
    
    public $koneksi;

    function __construct() {
        $this->koneksi = mysqli_connect($this->host, $this->username, $this->pass, $this->db, 3306);
        
        if (!$this->koneksi) {
            die("koneksi kedatabase gagal: " . mysqli_connect_error());
        }
    }
}
$conn = new m_koneksi();
